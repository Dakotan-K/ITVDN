public class Circle {
    public static void main(String[] args) {
        double PI = 3.1415926535897932384626D;
        int r = 5;
        double S = PI*Math.pow(r,2);
        System.out.println(S);
    }
}
