public class ArithmeticAverage {
    public static void main(String[] args) {
        int a = 10;
        int b = 15;
        int c = 20;
        int average = (a+b+c)/3;
        System.out.println(average);
    }
}
