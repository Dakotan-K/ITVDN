public class Volume {
    public static void main(String[] args) {
        double PI = 3.141592653589793238462643D;
        int R = 3;
        int h = 10;
        double V = PI*Math.pow(R,2)*h;
        double S = 2*PI*Math.pow(R,2)+2*PI*Math.pow(R,2);
        System.out.println("V = " + V);
        System.out.println("S = " + S);
    }
}
