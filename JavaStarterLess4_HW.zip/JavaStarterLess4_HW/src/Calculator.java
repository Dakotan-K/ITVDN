import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        double operand1 = 50;
        double operand2 = 8;
        double result;
        System.out.println("Дано два числа:" + "\n" + "Первое число = " + operand1 + "\n" + "Второе число = " + operand2 + "\n" + "Введите знак арифметической операции (+, -, *, /): ");
        Scanner in = new Scanner(System.in);
        String sing = in.next();

        switch (sing) {
            case "+":
                result = operand1 + operand2;
                System.out.println("Сумма = " + result);
                break;
            case "-":
                result = operand1 - operand2;
                System.out.println("Разность = " + result);
                break;
            case "*":
                result = operand1 * operand2;
                System.out.println("Произведение = " + result);
                break;
            case "/":
                if (operand2 == 0) {
                    System.out.println("Деление на 0! Операция отменена");
                }
                else {
                    result = operand1 / operand2;
                    System.out.println("Деление = " + result);
                }
                break;
        }
    }
}