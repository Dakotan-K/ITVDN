import java.util.Scanner;

public class Interval {
    public static void main(String[] args) {
        System.out.println("Введите число от 0 до 100: ");
        Scanner in = new Scanner(System.in);
        int interval = in.nextInt();
        if (interval <= 14) {
            if (interval >= 0) {
                System.out.println("Ваше число попадает в числовой промежуток [0 - 14]");
            } else System.out.println("Ваше число меньше указанного диапазона");
        } else if (interval >= 15) {
            if (interval <= 35) {
                System.out.println("Ваше число попадает в числовой промежуток [15 - 35]");
            } else if (interval >= 50) {
                if (interval <= 100) {
                    System.out.println("Ваше число попадает в числовой промежуток [50 - 100]");
                } else System.out.println("Ваше число больше указанного диапазона");
            } else System.out.println("Ваше число попадает в числовой промежуток [36 - 49]");
        }
    }
}
