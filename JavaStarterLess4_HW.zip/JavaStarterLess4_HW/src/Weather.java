import java.util.Scanner;
public class Weather {
    public static void main(String[] args) {
        System.out.println("Переводчик русских слов о погоде на английский язык. Введите слово: ");
        Scanner in = new Scanner(System.in);
        String weather = in.next();
        String engWord;

        switch (weather) {
            case "солнечно":
                engWord = "sunny";
                break;
            case "пасмурно":
                engWord = "cloudy";
                break;
            case "туман":
                engWord = "foggy";
                break;
            case "холодно":
                engWord = "coldly";
                break;
            case "тепло":
                engWord = "warm";
                break;
            case "жарко":
                engWord = "hot";
                break;
            default:
                engWord = "Вы ввели не верное слово";
                break;
        }
        System.out.println(engWord);
    }
}

