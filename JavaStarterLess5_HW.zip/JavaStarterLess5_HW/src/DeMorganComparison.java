public class DeMorganComparison {
    public static void main(String[] args) {
        // Согласно теореме Де Моргана, выражение A | B эквивалентно !(!A & !B).
        boolean a = false;
        boolean b = true;

        boolean c = !(!a & !b);
        System.out.println(c);
    }
}
