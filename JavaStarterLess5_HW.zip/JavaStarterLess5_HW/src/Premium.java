import java.util.Scanner;

public class Premium {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
            System.out.println("Введите свой трудовой стаж: ");
        int stag = in.nextInt();
            System.out.println("Введите свою зарплату: ");
        double money = in.nextDouble();

        if (stag >= 0 && stag < 5) {
            money = money * 1.1 - money;
            System.out.println("Размер Вашей премии 10% от зарплаты = " + money);
        } else if (stag >= 5 && stag < 10) {
            money = money * 1.15 - money;
            System.out.println("Размер Вашей премии 15% от зарплаты = " + money);
        } else if (stag >= 10 && stag < 15) {
            money = money * 1.25 - money;
            System.out.println("Размер Вашей премии 25% от зарплаты = " + money);
        } else if (stag >= 15 && stag < 20) {
            money = money * 1.35 - money;
            System.out.println("Размер Вашей премии 35% от зарплаты = " + money);
        } else if (stag >= 20 && stag < 25) {
            money = money * 1.45 - money;
            System.out.println("Размер Вашей премии 45% от зарплаты = " + money);
        } else if (stag >=25) {
            money = money * 1.5 - money;
            System.out.println("Размер Вашей премии 50% от зарплаты = " + money);
        }
    }
}
