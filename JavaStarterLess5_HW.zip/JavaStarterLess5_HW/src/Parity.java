import java.util.Scanner;

public class Parity {
    public static void main(String[] args) {
        System.out.println("Введите число: ");
        Scanner in = new Scanner(System.in);

        int value = in.nextInt();
        if ((value&1)==0) {
            System.out.println("Введенное число четное");
        } else {
            System.out.println("Введенное число нечетное");
        }
    }
}
