import java.util.Scanner;

public class PowerOfTwo {
    public static void main(String[] args) {

        System.out.println("Введите целое число: ");
        Scanner in = new Scanner(System.in);
        int res = in.nextInt();

        if((res%2) == 0) {
            System.out.println("Введенное число является степенью двойки");
        } else System.out.println("Введенной число не является степенью двойки");
    }
}
