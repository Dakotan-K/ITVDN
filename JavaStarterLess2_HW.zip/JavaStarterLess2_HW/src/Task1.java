public class Task1 {
    public static void main(String[] args) {

        float pi = 3.141592653f;
        double e = 2.7182818284590452d;
        String a = "2.7182818284590452";
        new Double(a); // нашел решение в интернете, прошу пояснить синтаксис

        System.out.println(pi);
        System.out.println(e);
        System.out.println(a);

    }
}
