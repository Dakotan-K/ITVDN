public class Task2 {
    public static void main(String[] args) {

        String a = "\nмоя строка 1";
        String b = "\tмоя строка 2";
        String c = "\fмоя строка 3"; // значениие \а не является командой, можно указать \b или \f

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

    }
}
